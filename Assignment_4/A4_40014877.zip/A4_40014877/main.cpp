#include "SlotMachine.h"
int main(){
  SlotMachine sm; //Creating an instance of slotMachine
  sm.run(); //Kicking off slot machine
  return 0;
}